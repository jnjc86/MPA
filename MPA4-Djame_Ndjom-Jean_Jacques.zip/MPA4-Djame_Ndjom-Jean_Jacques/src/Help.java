public class Help {
    public static String about() {
        return "FirstGradeFirstStep - A software solution to support first-grade students in learning the alphabet, counting, and basic mathematics.";
    }
}

