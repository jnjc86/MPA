import java.util.Scanner;

public class CountingModule {
    private int correctAnswers;

    public void displayCountingActivities() {
        System.out.println("Welcome to Counting Activities!");
        System.out.println("Let's count the objects:");
        for (int i = 1; i <= 5; i++) {
            System.out.println("Object " + i);
        }
        System.out.println("Great job! Now you can try counting other objects.");
    }

    public boolean countNumbers(Scanner scanner) {
        boolean continueModule = true;
        do {
            System.out.println("Let's practice counting!");
            for (int i = 1; i <= 100; i++) {
                System.out.println("Count: " + i);
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            System.out.println("Well done! You've successfully practiced counting.");
            correctAnswers++;
            if (askToContinue(scanner)) {
                continueModule = false;
            }
        } while (continueModule);
        return true;
    }

    private boolean askToContinue(Scanner scanner) {
        System.out.print("Do you want to continue this module? (yes/no): ");
        String choice = scanner.nextLine().trim().toLowerCase();
        return choice.equals("no");
    }

    public int getCorrectAnswers() {
        return correctAnswers;
    }
}