import java.util.Scanner;

public class AlphabetModule {
    private int correctAnswers;

    public void displayAlphabet() {
        System.out.println("Welcome to Alphabet Learning!");
        for (char letter = 'A'; letter <= 'Z'; letter++) {
            System.out.print(letter + " ");
        }
        System.out.println("\nNow it's time to quiz yourself!");
    }

    public void quizAlphabet(Scanner scanner) {
        boolean continueModule = true;

        do {
            System.out.println("Let's start the Alphabet Quiz!");

            for (char letter = 'A'; letter < 'Z'; letter++) {
                System.out.print("What comes after " + letter + "? ");
                char userAnswer = scanner.next().toUpperCase().charAt(0);

                if (userAnswer == (char) (letter + 1)) {
                    System.out.println("Correct!");
                    correctAnswers++;
                } else {
                    System.out.println("Incorrect. The correct answer is " + (char) (letter + 1));
                }
            }

            trackProgress();

            System.out.print("Do you want to continue this module? (yes/no): ");
            String choice = scanner.next().trim().toLowerCase();
            scanner.nextLine(); // Consume newline character
            if (choice.equals("no")) {
                continueModule = false;
            }

        } while (continueModule);
    }

    public void trackProgress() {
        double percentage = (double) correctAnswers / 26 * 100;
        System.out.println("Your progress: " + correctAnswers + " out of 26 correct. Percentage: " + percentage + "%");
    }

    public int getCorrectAnswers() {
        return correctAnswers;
    }
}