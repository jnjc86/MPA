import java.util.Scanner;

public class MathModule {
    private int correctAnswers;

    public void displayMathActivities() {
        System.out.println("Welcome to Math Activities!");
        System.out.println("Let's practice addition and subtraction:");
    }

    public boolean solveMathProblems(Scanner scanner) {
        int correctResult = generateMathProblem();

        System.out.print("Your answer: ");
        int userAnswer = scanner.nextInt();
        scanner.nextLine(); // Consume newline character

        if (userAnswer == correctResult) {
            System.out.println("Correct!");
            correctAnswers++;
            return true;
        } else {
            System.out.println("Incorrect. The correct answer is " + correctResult);
            return false;
        }
    }

    public int generateMathProblem() {
        int num1 = (int) (Math.random() * 10) + 1;
        int num2 = (int) (Math.random() * 10) + 1;
        System.out.println("What is the result of " + num1 + " + " + num2 + "?");
        return num1 + num2;
    }

    public int getCorrectAnswers() {
        return correctAnswers;
    }

    public void trackProgress() {
    }
}