import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class LearningHub {

    private List<AlphabetModule> alphabetModules = new ArrayList<>();
    private List<CountingModule> countingModules = new ArrayList<>();
    private List<MathModule> mathModules = new ArrayList<>();

    public void trackCountingProgress() {
        double percentage = (double) calculateCountingPoints() / 1 * 100;
        System.out.println("Counting Module Progress: " + calculateCountingPoints() + " out of 1 correct. Percentage: " + percentage + "%");
    }

    public void trackProgress() {
        System.out.println("Overall Progress:");
        trackAlphabetProgress();
        trackCountingProgress();
        trackMathProgress();
    }

    private void trackMathProgress() {
        double percentage = (double) calculateMathPoints() / (10 * mathModules.size()) * 100; // Assuming 10 questions per math module
        System.out.println("Math Module Progress: " + calculateMathPoints() + " out of " + (10 * mathModules.size()) + " correct. Percentage: " + percentage + "%");
    }

    private void trackAlphabetProgress() {
    }

    public void trackUserPoints() {
        int userPoints = 0;
        for (AlphabetModule module : alphabetModules) {
            userPoints += module.getCorrectAnswers();
        }
        userPoints += calculateCountingPoints();
        userPoints += calculateMathPoints();
        System.out.println("Total Points: " + userPoints);
    }

    private int calculateMathPoints() {
        int mathPoints = 0;
        for (MathModule module : mathModules) {
            mathPoints += module.getCorrectAnswers();
        }
        return mathPoints;
    }

    public int calculateCountingPoints() {
        int countingPoints = 0;
        for (CountingModule module : countingModules) {
            countingPoints += module.getCorrectAnswers();
        }
        return countingPoints;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        boolean exit = false;

        do {
            System.out.println(Help.about());

            LearningHub learningHub = new LearningHub();
            learningHub.customizePreferences(scanner);

            if (learningHub.alphabetModules.isEmpty() && learningHub.countingModules.isEmpty() && learningHub.mathModules.isEmpty()) {
                System.out.println("Please select at least one module.");
                continue;
            }

            for (AlphabetModule alphabetModule : learningHub.alphabetModules) {
                alphabetModule.displayAlphabet();
                alphabetModule.quizAlphabet(scanner);
                alphabetModule.trackProgress();
                learningHub.trackUserPoints();
            }

            for (MathModule mathModule : learningHub.mathModules) {
                mathModule.displayMathActivities();
                boolean continueMathModule = true;
                while (continueMathModule) {
                    boolean isCorrect = mathModule.solveMathProblems(scanner);
                    learningHub.trackUserPoints();

                    if (!isCorrect) {
                        System.out.print("Do you want to continue this module? (yes/no): ");
                        String choice = scanner.nextLine().trim().toLowerCase();
                        if (choice.equals("no")) {
                            continueMathModule = false;
                        }
                    }
                }
            }

            for (CountingModule countingModule : learningHub.countingModules) {
                countingModule.displayCountingActivities();
                countingModule.countNumbers(scanner);
                learningHub.trackUserPoints();
            }

            learningHub.trackProgress();

            System.out.print("Do you want to choose different modules? (yes/no): ");
            String restartChoice = scanner.nextLine().trim().toLowerCase();
            if (restartChoice.equals("no")) {
                System.out.print("Do you want to exit the software? (yes/no): ");
                String exitChoice = scanner.nextLine().trim().toLowerCase();
                if (exitChoice.equals("yes")) {
                    exit = true;
                    break;
                }
            }

        } while (!exit);

        scanner.close();
        System.out.println("Thank you for using the learning software!");
    }

    public void customizePreferences(Scanner scanner) {
        boolean validInput = false;

        System.out.println("Customize Your Learning Preferences:");
        System.out.println("1. Alphabet Module");
        System.out.println("2. Counting Module");
        System.out.println("3. Math Module");
        System.out.println("4. Exit");

        do {
            System.out.print("Enter the numbers of modules you want to include (comma-separated): ");
            String selectedModulesInput = scanner.nextLine();
            String[] selectedModulesArray = selectedModulesInput.split(",");

            for (String moduleNumber : selectedModulesArray) {
                try {
                    int moduleNum = Integer.parseInt(moduleNumber.trim());
                    switch (moduleNum) {
                        case 1:
                            alphabetModules.add(new AlphabetModule());
                            break;
                        case 2:
                            countingModules.add(new CountingModule());
                            break;
                        case 3:
                            mathModules.add(new MathModule());
                            break;
                        case 4:
                            System.out.println("Exiting the software...");
                            System.exit(0);
                        default:
                            System.out.println("Invalid module number: " + moduleNum);
                    }
                } catch (NumberFormatException e) {
                    System.out.println("Invalid input: " + moduleNumber);
                }
            }

            if (!alphabetModules.isEmpty() || !countingModules.isEmpty() || !mathModules.isEmpty()) {
                validInput = true;
            }

        } while (!validInput);

        System.out.println("Your preferences have been updated!");
    }
}